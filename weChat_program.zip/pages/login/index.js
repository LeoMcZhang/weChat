//index.js
//获取应用实例
const app = getApp()

Page({
  data: {
  },
  // 钩子函数
  onLoad: function () {
  },
  loginTap: function () {
    var obj = {
      userName: 'zyx'
    }
    wx.setStorage({
      key: 'accountInfo',
      data: obj,
      success: function () {
        wx.navigateBack()
      }
    })
  }
})
