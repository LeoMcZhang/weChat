//index.js
//获取应用实例

const app = getApp()

Page({
  data: {},
  onLoad: function (option) {
    var path       = 'music/url',
        pathDetail = 'music/detail',
        data       = {id: option.id, br: '128000'},
        dataDetail = {id: option.id}
    app.GetData(path, data).get(function (e) {
      console.log(e)
    })
    app.GetData(pathDetail, dataDetail).get(function (e) {
      console.log(e)
    })
  }
})