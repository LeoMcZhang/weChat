/*
* @Author: zyx
* @Date:   2017-10-16 16:21:20
* @Last Modified by:   name
* @Last Modified time: 2017-10-16 16:21:38
*/
module.exports="http://localhost:3000/v1/"