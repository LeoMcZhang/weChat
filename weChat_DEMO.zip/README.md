# netmusic-app

那个。。。。我有一个不成熟的小建议。。
如果。。。我是说如果。。。你觉得有用的话。。
那个。。。。能不能star一下。。


仿网易云音乐APP的微信小程序

[还有Vue版本哦](https://github.com/sqaiyan/neteasemusic)

需后端支持
下载启动[node服务端](https://github.com/sqaiyan/netmusic-node)即可

 [动图演示地址：又大又长](http://7vik7b.com1.z0.glb.clouddn.com/20170308_112339.gif)


##目前实现功能

1. 用户
2. 歌单
3. FM
4. 播放
5. 评论
6. MV
7. 专辑
8. 歌手
9. 登录
10. 歌曲红心,FM trash，收藏单曲至歌单
11. 收听记录
12. 歌单歌曲推荐
13. 迷你播放条
14. 电台，节目
15. 搜索

##TODO

* 增加评论，评论点赞等 
* 歌词翻译
* 收藏(歌单，歌手，专辑，电台
* 音质切换
* 用户动态，粉丝
* 新歌 新专 分类电台
 
<image width="320" src="http://7vik7b.com1.z0.glb.clouddn.com/IMG_4271.PNG"/>
<image width="320" src="http://7vik7b.com1.z0.glb.clouddn.com/IMG_4279.PNG"/>
<image width="320" src="http://7vik7b.com1.z0.glb.clouddn.com/IMG_4274.PNG"/>
<image width="320" src="http://7vik7b.com1.z0.glb.clouddn.com/IMG_4272.PNG"/>
<image width="320" src="http://7vik7b.com1.z0.glb.clouddn.com/IMG_4276.PNG"/>
<image width="320" src="http://7vik7b.com1.z0.glb.clouddn.com/IMG_4277.PNG"/>
<image width="320" src="http://7vik7b.com1.z0.glb.clouddn.com/IMG_4275.PNG"/>
<image width="320" src="http://7vik7b.com1.z0.glb.clouddn.com/IMG_4273.PNG"/>
<image width="320" src="http://7vik7b.com1.z0.glb.clouddn.com/IMG_4278.PNG"/>
